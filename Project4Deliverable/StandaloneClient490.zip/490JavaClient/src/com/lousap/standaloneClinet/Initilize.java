package com.lousap.standaloneClinet;

import java.sql.SQLException;
import java.lang.ClassNotFoundException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class Initilize 
{
	
	public static void main(String[] args)
	{
		

		GUIMenu guiMenu = new GUIMenu(500, 500);

	}
}


----------------------------------
IMAGEINFO CACHE MODULE
----------------------------------


CONTENTS OF THIS FILE
---------------------

 * Features & benefits
 * Configuration


FEATURES & BENEFITS
-------------------

Imageinfo cache features:
 * Generation of selected image styles right after an image is uploaded.
 * Will also run the generation code upon node save.
 * If the HTTPRL module is installed, generation logic will work in the
   background. http://drupal.org/project/httprl/
 * Drush intergration. Can do bulk image style generation.

CONFIGURATION
-------------

Settings page is located at: admin/config/media/imageinfo_cache


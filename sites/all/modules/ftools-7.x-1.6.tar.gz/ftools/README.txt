// Features tools
Features tools is a drupal module.
It's a develop helper module for working with Feature module.
It's add a submit button in the recreate feature form named "auto create feature",
which download the feature tar ball, un-tar it and put the files in the right place.
All in one click. 

Any one how use the recreate feature more then few time a day will probably like this feature.

In order to make the module to work you need to give www-data ,permission to write to the sites/all/modules directory.
THIS MODULE IS FOR LOCAL SERVER DEVELOPING ONLY !!!
It's probably won't work other places but please don't try.



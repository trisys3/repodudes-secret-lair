<div class="rules-link-wrapper rules-link-<?php print $rules_link->name ?>">
  <a href="<?php print $href ?>" <?php print $attr ?>><?php print $title ?></a>
</div>

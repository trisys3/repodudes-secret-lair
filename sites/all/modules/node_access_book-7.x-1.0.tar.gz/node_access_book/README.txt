
Node access book README

CONTENTS OF THIS FILE
----------------------

  * Introduction
  * Requirements
  * Installation
  * Usage
  

INTRODUCTION
------------
Gives content access permissions to users if they have access to content that is
referenced with node reference.  Checks view, update, and delete grant 
operations, and can pass those on to the referencing content, or trigger a
different grant configuration according to settings.

Project page: http://drupal.org/project/nodeaccess_nodereference.


REQUIREMENTS
------------
This module requires the Book module to be enabled.


INSTALLATION
------------
Install and enable the Node access book module.
For detailed instructions on installing contributed modules see:
http://drupal.org/documentation/install/modules-themes/modules-7


USAGE
-----
???
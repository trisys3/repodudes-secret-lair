-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 16, 2013 at 01:39 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `capstone_njhitec`
--

-- --------------------------------------------------------

--
-- Table structure for table `objective results`
--
-- Creation: Oct 11, 2013 at 02:18 PM
--

CREATE TABLE IF NOT EXISTS `objective results` (
  `Assessment ID` bigint(20) NOT NULL,
  `Objective ID` bigint(20) NOT NULL,
  `Total Amount` int(11) NOT NULL,
  `Percent Completed` double NOT NULL,
  `Achieved` tinyint(1) DEFAULT NULL,
  `Comments` varchar(60000) NOT NULL,
  `Status` varchar(8) NOT NULL,
  PRIMARY KEY (`Assessment ID`,`Objective ID`),
  KEY `Total Amount` (`Total Amount`,`Percent Completed`,`Comments`(767),`Status`),
  KEY `Achieved` (`Achieved`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `objectives`
--
-- Creation: Oct 04, 2013 at 04:04 AM
--

CREATE TABLE IF NOT EXISTS `objectives` (
  `Objective ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Objective Name` varchar(13000) NOT NULL,
  `Meaningful Use Measure` varchar(13000) NOT NULL,
  `Total Criteria` bigint(20) NOT NULL,
  `Paper Charts` varchar(13000) DEFAULT NULL,
  `Points to Note` varchar(13000) NOT NULL,
  `Comments` varchar(13000) DEFAULT NULL,
  `Threshold` bigint(20) NOT NULL,
  PRIMARY KEY (`Objective ID`),
  KEY `Objective Name` (`Objective Name`(767),`Meaningful Use Measure`(767),`Total Criteria`,`Paper Charts`(767)),
  KEY `Points to Note` (`Points to Note`(767),`Comments`(767),`Threshold`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `practices`
--
-- Creation: Oct 10, 2013 at 08:01 PM
--

CREATE TABLE IF NOT EXISTS `practices` (
  `Practice Tax ID` int(9) NOT NULL,
  `Practice Name` varchar(65000) NOT NULL,
  PRIMARY KEY (`Practice Tax ID`),
  KEY `Practice Name` (`Practice Name`(767))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `providers`
--
-- Creation: Oct 04, 2013 at 04:15 AM
--

CREATE TABLE IF NOT EXISTS `providers` (
  `NPI` bigint(20) NOT NULL,
  `Tax ID` int(11) NOT NULL,
  `Provider Name` varchar(5000) NOT NULL,
  `Product Go Live Date` varchar(5000) NOT NULL,
  `Contact Email Address` varchar(5000) NOT NULL,
  `Vendor` varchar(5000) NOT NULL,
  `Product` varchar(5000) NOT NULL,
  `Version Number` varchar(5000) NOT NULL,
  `Registered` varchar(5000) NOT NULL,
  `ONC Certification Number` varchar(5000) NOT NULL,
  `Medicare or Medicaid` varchar(5000) NOT NULL,
  PRIMARY KEY (`NPI`),
  KEY `Provider Name` (`Provider Name`(767),`Product Go Live Date`(767),`Contact Email Address`(767)),
  KEY `Vendor` (`Vendor`(767),`Product`(767),`Version Number`(767)),
  KEY `Registered` (`Registered`(767),`ONC Certification Number`(767),`Medicare or Medicaid`(767))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `results`
--
-- Creation: Oct 04, 2013 at 04:18 AM
--

CREATE TABLE IF NOT EXISTS `results` (
  `Assessment ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Start Date` varchar(8000) NOT NULL,
  `End Date` varchar(8000) NOT NULL,
  `Comments` varchar(8000) DEFAULT NULL,
  `Next Steps` varchar(8000) DEFAULT NULL,
  `Status` varchar(8000) DEFAULT NULL,
  `Assessment Date` varchar(8000) NOT NULL,
  `Met With` varchar(8000) NOT NULL,
  `Assessment Taken By` varchar(8000) NOT NULL,
  PRIMARY KEY (`Assessment ID`),
  KEY `Assessment Taken By` (`Assessment Taken By`(767)),
  KEY `Start Date` (`Start Date`(767),`End Date`(767)),
  KEY `Comments` (`Comments`(767),`Next Steps`(767),`Status`(767)),
  KEY `Assessment Date` (`Assessment Date`(767),`Met With`(767),`Assessment Taken By`(767))
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
